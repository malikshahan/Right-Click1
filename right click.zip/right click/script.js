    // DOM Content Loaded
    document.addEventListener('DOMContentLoaded', function () {
        initializeWebsite();
    });

    function initializeWebsite() {
        initSmoothScrolling();
        initScrollAnimations();
        initMobileMenu();
        initTypingEffect();
        initParallaxEffect();
        initServiceCardInteractions();
        initContactForm();
        initParticleEffect();
        initScrollProgress();
        initBackToTop();
        // Uncomment below if you want hover sound
        // addHoverSounds();
    }

    function initSmoothScrolling() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });
    }

    function initScrollAnimations() {
        const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    if (entry.target.classList.contains('service-card')) {
                        const cards = entry.target.parentElement.querySelectorAll('.service-card');
                        cards.forEach((card, index) => {
                            setTimeout(() => {
                                card.style.opacity = '1';
                                card.style.transform = 'translateY(0)';
                            }, index * 200);
                        });
                    }
                }
            });
        }, observerOptions);

        document.querySelectorAll('.service-card, .fade-in').forEach(el => observer.observe(el));
    }

    function initMobileMenu() {
        const mobileMenuBtn = document.querySelector('.md\\:hidden');
        const nav = document.querySelector('nav');

        if (mobileMenuBtn) {
            mobileMenuBtn.addEventListener('click', function () {
                nav.classList.toggle('flex');
                nav.classList.toggle('hidden');
                nav.classList.toggle('absolute');
                nav.classList.toggle('top-full');
                nav.classList.toggle('left-0');
                nav.classList.toggle('right-0');
                nav.classList.toggle('bg-black');
                nav.classList.toggle('p-6');
                nav.classList.toggle('flex-col');
                nav.classList.toggle('space-y-4');
            });
        }
    }

    function initTypingEffect() {
        const heroTitle = document.querySelector('.hero-bg h2');
        if (heroTitle) {
            const text = heroTitle.textContent;
            heroTitle.textContent = '';
            heroTitle.style.borderRight = '3px solid #22d3ee';

            let i = 0;
            const typeWriter = () => {
                if (i < text.length) {
                    heroTitle.textContent += text.charAt(i);
                    i++;
                    setTimeout(typeWriter, 100);
                } else {
                    heroTitle.style.borderRight = 'none';
                }
            };
            setTimeout(typeWriter, 1000);
        }
    }

    function initParallaxEffect() {
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const parallax = document.querySelector('.hero-bg');
            if (parallax) {
                const speed = scrolled * 0.5;
                parallax.style.transform = `translateY(${speed}px)`;
            }
        });
    }

    function initServiceCardInteractions() {
        const cards = document.querySelectorAll('.service-card');
        cards.forEach(card => {
            card.addEventListener('click', () => {
                card.style.transform = 'scale(0.95)';
                setTimeout(() => card.style.transform = '', 150);
            });

            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-10px) scale(1.03)';
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
            });
        });
    }

    function initContactForm() {
        const contactLinks = document.querySelectorAll('a[href^="mailto:"], a[href^="tel:"]');
        contactLinks.forEach(link => {
            link.addEventListener('click', function () {
                this.style.transform = 'scale(0.95)';
                setTimeout(() => this.style.transform = '', 150);
            });
        });
    }

    function initParticleEffect() {
        const hero = document.querySelector('.hero-bg');
        if (hero) {
            for (let i = 0; i < 50; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.cssText = `
                    position: absolute;
                    width: 2px;
                    height: 2px;
                    background: rgba(34, 211, 238, 0.3);
                    border-radius: 50%;
                    pointer-events: none;
                    animation: float-particle ${Math.random() * 3 + 2}s infinite linear;
                    left: ${Math.random() * 100}%;
                    top: ${Math.random() * 100}%;
                `;
                hero.appendChild(particle);
            }

            const style = document.createElement('style');
            style.textContent = `
                @keyframes float-particle {
                    0% { transform: translateY(0px) rotate(0deg); opacity: 0; }
                    10% { opacity: 1; }
                    90% { opacity: 1; }
                    100% { transform: translateY(-100vh) rotate(360deg); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }
    }

    function initScrollProgress() {
        const progressBar = document.createElement('div');
        progressBar.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 0%;
            height: 3px;
            background: linear-gradient(90deg, #22d3ee, #06b6d4);
            z-index: 9999;
            transition: width 0.1s ease;
        `;
        document.body.appendChild(progressBar);

        window.addEventListener('scroll', () => {
            const scrolled = (window.pageYOffset / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
            progressBar.style.width = scrolled + '%';
        });
    }

    function initBackToTop() {
        const backToTop = document.createElement('button');
        backToTop.innerHTML = '<i class="fas fa-arrow-up"></i>';
        backToTop.style.cssText = `
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #22d3ee, #06b6d4);
            border: none;
            border-radius: 50%;
            color: black;
            font-size: 18px;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 1000;
            box-shadow: 0 4px 15px rgba(34, 211, 238, 0.3);
        `;
        document.body.appendChild(backToTop);

        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTop.style.opacity = '1';
                backToTop.style.visibility = 'visible';
            } else {
                backToTop.style.opacity = '0';
                backToTop.style.visibility = 'hidden';
            }
        });

        backToTop.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        backToTop.addEventListener('mouseenter', function () {
            this.style.transform = 'scale(1.1)';
            this.style.boxShadow = '0 6px 20px rgba(34, 211, 238, 0.4)';
        });

        backToTop.addEventListener('mouseleave', function () {
            this.style.transform = 'scale(1)';
            this.style.boxShadow = '0 4px 15px rgba(34, 211, 238, 0.3)';
        });
    }

    window.addEventListener('load', () => {
        document.body.style.opacity = '0';
        document.body.style.transition = 'opacity 0.5s ease';
        setTimeout(() => {
            document.body.style.opacity = '1';
        }, 100);
    });

    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            const nav = document.querySelector('nav');
            if (nav.classList.contains('flex')) {
                nav.classList.remove('flex');
                nav.classList.add('hidden');
            }
        }
    });

    function animateCounters() {
        const counters = document.querySelectorAll('.counter');
        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-target'));
            const increment = target / 100;
            let current = 0;

            const updateCounter = () => {
                if (current < target) {
                    current += increment;
                    counter.textContent = Math.ceil(current);
                    setTimeout(updateCounter, 20);
                } else {
                    counter.textContent = target;
                }
            };
            updateCounter();
        });
    }

    const counterObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounters();
            }
        });
    });
    document.querySelectorAll('.counter').forEach(el => counterObserver.observe(el));

    function addHoverSounds() {
        const interactiveElements = document.querySelectorAll('a, button, .service-card');
        interactiveElements.forEach(element => {
            element.addEventListener('mouseenter', () => {
                const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT');
                audio.volume = 0.1;
                audio.play().catch(() => {});
            });
        });
    }

